package rumievittar.nicolas.parcial1.pkg122;

import entidades.AgenciaEspacial;
import entidades.Carguero;
import entidades.CruceroEstelar;
import entidades.NaveExploracion;
import entidades.TipoMision;


public class RumievittarNicolasParcial1122 {

    
    public static void main(String[] args) {
        AgenciaEspacial agencia = new AgenciaEspacial();
        
        NaveExploracion ne1 = new NaveExploracion("Carlos", 2, 2000, TipoMision.CONTACTO);
        NaveExploracion ne2 = new NaveExploracion("Pedro", 4, 2005, TipoMision.INVESTIGACION);
        
        CruceroEstelar ce1 = new CruceroEstelar("Gaston", 50, 2010, 500);
        Carguero c1 = new Carguero("Carguero Supremo", 10, 2015, 200);
        
        agencia.agregarNave(ne1);        
        agencia.agregarNave(ne2);
        agencia.agregarNave(ce1);
        agencia.agregarNave(c1);
        
        //System.out.println(agencia.filtrarPorMision(TipoMision.CONTACTO));
        
        Carguero c2 = new Carguero("Galactica", 10, 2025, 300);
        Carguero c3 = new Carguero("Galactica", 5, 2025, 200);
        
        agencia.agregarNave(c2);
        //agencia.agregarNave(c3);
        
        agencia.iniciarExploracion();

        
        agencia.listarNaves();
        
        //agencia.agregarNave(ne1);

        
    }
    
}
