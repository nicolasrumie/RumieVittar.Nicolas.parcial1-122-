package rumievittar.nicolas.parcial1.pkg122;

import entidades.AgenciaEspacial;
import entidades.Carguero;
import entidades.CruceroEstelar;
import entidades.NaveExploracion;
import entidades.TipoMision;


public class RumievittarNicolasParcial1122 {

    
    public static void main(String[] args) {
        
        AgenciaEspacial agencia = new AgenciaEspacial();
        
        CruceroEstelar crucero1  = new CruceroEstelar("A", 10, 2000, 200);        
        CruceroEstelar crucero2  = new CruceroEstelar("B", 15, 2012, 100);
        
        NaveExploracion nave1 = new NaveExploracion("A1EXP", 10, 2007, TipoMision.CONTACTO);
        NaveExploracion nave2 = new NaveExploracion("B2EXP", 10, 2003, TipoMision.INVESTIGACION);
        NaveExploracion nave3 = new NaveExploracion("C3EXP", 10, 2000, TipoMision.INVESTIGACION);
        
        NaveExploracion nave4 = new NaveExploracion("D4EXP", 10, 2333, TipoMision.CONTACTO);
        NaveExploracion nave5 = new NaveExploracion("D4EXP", 10, 2333, TipoMision.CONTACTO);
        
        Carguero carguero = new Carguero("Galactica", 10, 2025, 300);
        
        agencia.agregarNave(carguero);
        agencia.agregarNave(crucero1);
        agencia.agregarNave(crucero2);
        agencia.agregarNave(nave1);
        agencia.agregarNave(nave2);
        agencia.agregarNave(nave3);
        agencia.agregarNave(nave4);
        agencia.agregarNave(nave5);
        
        
        
        agencia.iniciarExploracion();
        
  
    }
    
}
