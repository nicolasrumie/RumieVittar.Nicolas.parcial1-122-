
package exception;


public class NaveRepetidaException extends RuntimeException{
    private static final String MESSAGE = "Nave repetida";

    public NaveRepetidaException() {
        this(MESSAGE);
    }

    public NaveRepetidaException(String message) {
        super(message);
    }
    
    
}
