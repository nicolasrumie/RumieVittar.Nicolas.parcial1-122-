package interfaces;


public interface Explorable {
    public void explorar();
}
