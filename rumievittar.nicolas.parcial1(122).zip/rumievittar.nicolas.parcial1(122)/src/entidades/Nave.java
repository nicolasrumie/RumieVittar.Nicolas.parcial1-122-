package entidades;

import java.util.Objects;


public class Nave {
    
    private final String nombre;
    private final int cantidadDeTripulacion;
    private final int anioLanzamiento;  

    public Nave(String nombre, int cantidadDeTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.cantidadDeTripulacion = cantidadDeTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(o == null || !(o instanceof Nave n))
        {
            return false;
        }
        return nombre.equals(n.nombre) && anioLanzamiento == n.anioLanzamiento;
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(nombre, anioLanzamiento);
    }

    @Override
    public String toString() {
        return "Nave{" + "nombre=" + this.nombre + ", cantidadDeTripulacion=" + this.cantidadDeTripulacion + ", anioLanzamiento=" + this.anioLanzamiento + '}';
    }

    public String getNombre() {
        return nombre;
    }
  
   
}
