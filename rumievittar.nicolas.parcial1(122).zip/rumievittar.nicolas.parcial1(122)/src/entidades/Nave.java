package entidades;


public abstract class Nave {
    public String nombre;
    public int cantidadDeTripulacion;
    public int anioLanzamiento;  

    public Nave(String nombre, int cantidadDeTripulacion, int anioLanzamiento) {
        this.nombre = nombre;
        this.cantidadDeTripulacion = cantidadDeTripulacion;
        this.anioLanzamiento = anioLanzamiento;
    }
   
}
