
package entidades;


public enum TipoMision {
    CARTOGRAFIA,
    INVESTIGACION,
    CONTACTO
}
