package entidades;

import interfaces.Mantenible;
import java.util.Objects;


public class CruceroEstelar extends Nave implements Mantenible{
    
    private int psajeros;

    public CruceroEstelar(String nombre, int cantidadDeTripulacion, int anioLanzamiento, int pasajeros) {
        super(nombre, cantidadDeTripulacion, anioLanzamiento);
        this.psajeros = pasajeros;
    } 
    
    @Override
    public void realizarMantenimiento()
    {
        System.out.println("Crucero en mantenimiento");
    }

    @Override
    public String toString() {
        return "Crucero estelar: " + nombre + "\ncantidad de tripulacion: " + cantidadDeTripulacion + "\naño de lanzamiento: " + anioLanzamiento;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(o == null || !(o instanceof CruceroEstelar n))
        {
            return false;
        }
        return nombre.equals(n.nombre) && anioLanzamiento == n.anioLanzamiento;
      
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(nombre);
    }
    
    
    
}
