package entidades;

import exception.NaveRepetidaException;
import java.util.ArrayList;


public class AgenciaEspacial {
    private ArrayList<Nave> naves;

    public AgenciaEspacial() {
        this.naves = new ArrayList<>();
    }
    
    private static void checkNull(Nave n)
    {
        if(n == null)
        {
            throw new NullPointerException("Error. Objero nulo.");
        }
    }
    
    public void iniciarExploracion()
    {
        for(Nave n : naves)
        {
            if(!(n instanceof NaveExploracion ne))
            {
                System.out.println("La nave: " + n.nombre + " no puede iniciar exploraciones.");
            }
            else
            {
                System.out.println("La nave " + n.nombre + " ha iniciado su ruta");
            }
        }
    }
    
    public void checkRepetidas(Nave n)
    {
        for(Nave nave : naves)
        {
            if(nave.equals(n))
            {
                throw new NaveRepetidaException();
            }
        }
    }
    
    public boolean validarListaVacia()
    {
        return naves.isEmpty();
    }
    
    
    public void agregarNave(Nave n)
    {
        checkNull(n);
        checkRepetidas(n);
        naves.add(n);
    }
    
    public void listarNaves()
    {
        if(validarListaVacia())
        {
            System.out.println("No hay naves en el hangar.");
        }
        else
        {
            for(Nave n : naves)
            {
                System.out.println(n);
            }
        }
    }
    
    public ArrayList<NaveExploracion> filtrarPorMision(TipoMision t)
    {
        ArrayList<NaveExploracion> navesPorMision = new ArrayList<>();
        for(Nave n : naves)
        {
            if(n instanceof NaveExploracion)
            {
                if(((NaveExploracion) n).mision == t)
                {
                    navesPorMision.add((NaveExploracion) n);
                }
            }
        }
        return navesPorMision;
    }   
}
