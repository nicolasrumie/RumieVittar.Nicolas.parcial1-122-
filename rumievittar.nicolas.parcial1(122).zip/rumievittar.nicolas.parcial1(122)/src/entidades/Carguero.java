package entidades;

import interfaces.Explorable;
import interfaces.Mantenible;
import java.util.Objects;


public class Carguero extends Nave implements Mantenible, Explorable{
    public static final int MIN_TONELADAS = 100;
    public static final int MAX_TONELADAS = 500;
    private int cargaToneladas;

    public Carguero(String nombre, int cantidadDeTripulacion, int anioLanzamiento, int cargaToneladas) {
        super(nombre, cantidadDeTripulacion, anioLanzamiento);
        this.cargaToneladas = validarPeso(cargaToneladas);
    }
    
    private static int validarPeso(int peso)
    {
        if(peso > MAX_TONELADAS || peso < MIN_TONELADAS)
        {
            throw new IllegalArgumentException("Peso fuera del permitido.");
        }
        else
        {
            return peso;
        }
    }
    
    @Override
    public void explorar()
    {
        System.out.println("Carguero: " + nombre + " explorando...");
    }
    
    @Override
    public void realizarMantenimiento()
    {
        System.out.println("Carguero en mantenimiento. ");
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(o == null || !(o instanceof Carguero n))
        {
            return false;
        }
        return nombre.equals(n.nombre) && anioLanzamiento == n.anioLanzamiento;
      
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(nombre);
    }
    
    @Override
    public String toString() {
        return "Nave carguero: " + nombre + "\ncantidad de tripulacion: " + cantidadDeTripulacion + "\naño de lanzamiento: " + anioLanzamiento;
    }
    
    
}
