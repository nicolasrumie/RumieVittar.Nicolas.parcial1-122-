package entidades;

import interfaces.Explorable;


public class NaveExploracion extends Nave implements Explorable{
    public TipoMision mision;

    public NaveExploracion(String nombre, int cantidadDeTripulacion, int anioLanzamiento, TipoMision mision) {
        super(nombre, cantidadDeTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    public TipoMision getMision() {
        return mision;
    }
    
    @Override
    public void explorar()
    {
        System.out.println("Nave de exploracion --Inicio de patrulla--");
    }

    @Override
    public String toString() {
        return super.toString() + mision;
    }
     
    
}
