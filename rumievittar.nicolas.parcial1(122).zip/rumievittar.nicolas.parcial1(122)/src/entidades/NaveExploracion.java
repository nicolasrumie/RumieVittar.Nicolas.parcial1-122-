package entidades;

import interfaces.Explorable;
import java.util.Objects;


public class NaveExploracion extends Nave implements Explorable{
    public TipoMision mision;

    public NaveExploracion(String nombre, int cantidadDeTripulacion, int anioLanzamiento, TipoMision mision) {
        super(nombre, cantidadDeTripulacion, anioLanzamiento);
        this.mision = mision;
    }

    public TipoMision getMision() {
        return mision;
    }
    
    @Override
    public void explorar()
    {
        System.out.println("Nave de exploracion --Inicio de patrulla--");
    }

    @Override
    public String toString() {
        return "Nave de Exploracion: " + nombre + "\ncantidad de tripulacion: " + cantidadDeTripulacion + "\naño de lanzamiento: " + anioLanzamiento + "\ntipo de mision: " + mision;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(o == null || !(o instanceof NaveExploracion n))
        {
            return false;
        }
        return nombre.equals(n.nombre) && anioLanzamiento == n.anioLanzamiento;
      
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(nombre);
    }
     
    
}
